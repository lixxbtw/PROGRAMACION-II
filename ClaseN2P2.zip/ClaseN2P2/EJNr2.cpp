#include <iostream>

using namespace std;

/// SOBRECARGA DE FUNCIONES---- Mismo nombre, distintas funciones

/// tipo_dato nombre_funcion (_parametros_)

/// DECLARACION/DEFINICION

int sumar (int , int);
int sumar(float, float);
int sumar(int (*), int);
int sumar (int v[],int t);
int sumar (int *v,int t);


int main(){
    /**
    const int var=5;
    int v [var];
    */
    const int TAM=5;
    int vec[TAM];

    cout << "Sumar vectores es: " << sumar(vec,TAM) << endl;

    cout << "Sumar es: " << sumar (5,9) << endl;

    cout << "Sumar es: " << sumar(5.0f,3.0f) << endl;  /// .0F convierte entero a float ""


	return 0;
}

///IMPLEMENTACION


int sumar (int a, int b ){
    cout << "Entero" << endl;
    return a + b;
}

int sumar (float a, float b){
    cout << "Float" << endl;
    return a + b;
}
int sumar (int v[], int t){

    int acu=0;
    for (int i=0;i<t;i++){
        acu+= *(v+i);     /// AMBOS SON IGUALES, HACEN LO MISMO
        ///acu += v[i];
    }

    return acu;
}


