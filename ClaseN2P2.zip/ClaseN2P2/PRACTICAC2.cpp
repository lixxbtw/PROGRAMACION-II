#include <iostream>

using namespace std;

/**

A) Monto total recaudado
B) Monto por cada articulo  ------- uso un vector de recaudaciones
C) Monto total por articulo y sucursal ------- uso una matriz de tama�o 10x4


*/


int main(){


    int nroArt;
    int nroSuc;
    float monto;
    float montoTotal=0;

    cout << "Ingrese el numero de articulo: "<< endl;
    cin >> nroArt;

    while (nroArt!=0){

        if (nroSuc<=1 && nroSuc>=4){

            cout << "Ingrese num. sucursal: " << endl;
            cin >> nroSuc;
            cout << "Ingrese monto: " << endl;
            cin >> monto;


            ///PROCESO
            montoTotal+= monto;


        }

        cout << "Ingrese el numero de articulo: "<< endl;
        cin >> nroArt;


    }
    cout <<"Recaudacion total $: " << montoTotal<< endl;




	return 0;
}
