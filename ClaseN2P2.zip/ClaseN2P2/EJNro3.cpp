#include <iostream>
#include <cstring>

using namespace std;
///PARAMETROS POR OMISION

void saludar (string nombre = "Usuario", int entero=0){ ///Por omision a entero le asigno 0 y lo hay error
    cout << "Hola " <<nombre << endl;

}

/**
void saludar (string nombre){
    cout << "Hola" << nombre  << endl;

}
*/

int main(){

    saludar ("Valentin", 5);
    ///saludar (" Nombre");

	return 0;
}
