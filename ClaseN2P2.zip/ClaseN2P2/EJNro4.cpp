#include <iostream>

using namespace std;

///FUNCION MOSTRAR

void mostrar(int m[][3],int f, int c);
void mostrar2(int m[][3],int f, int c);
void cargar(int m[][3],int f, int c);




int main(){
    /**

    int vec [5]={0}; /// TODO EL VECTOR EN CERO

    cout << vec [4];

    */



    ///MATRICES


    int const F = 3;
    int const C = 3;
    int mat [F] [C] = { {1,2,3}, {4}, {1,1,9}};  ///LE DOY VALORES A LA MATRIZ

    /// Muestro columnas sin ciclos

    /**

    cout << mat [0][0] << endl;
    cout << mat [0][1] << endl;
    cout << mat [0][2] << endl;
    cout << mat [1][0] << endl;
    cout << mat [1][1] << endl;
    cout << mat [1][2] << endl;
    cout << mat [2][0] << endl;
    cout << mat [2][1] << endl;
    cout << mat [2][2] << endl;
    */


    cargar (mat,F,C);
    cout << "------------------------------"<<endl;
    mostrar (mat,F,C);
    cout << "------------------------------"<<endl;
    mostrar2 (mat,F,C);
    cout << "------------------------------"<<endl;


    /**
    cout << mat << endl;
    cout << &mat[0][0] << endl;
    cout << sizeof mat << " Bytes" << endl;
    */




	return 0;
}



void mostrar(int m[][3],int f, int c){

    for (int i=0; i<f; i++){

        for (int j=0; j< c; j++){
            cout << m[i][j]<< "\t";
        }
        cout <<"\n";
    }
}

void mostrar2(int m[][3],int f, int c){

    for (int i=0; i<f; i++){

        for (int j=0; j< c; j++){
            cout << &(m[i][j])<< "\t";
        }
        cout <<"\n";
    }

}
void cargar (int m[][3],int f, int c){
    int cont=0;
    for (int i=0; i<f; i++){
        for (int j=0; j< c; j++){
            m[i][j] = ++cont;
        }
    }
}
