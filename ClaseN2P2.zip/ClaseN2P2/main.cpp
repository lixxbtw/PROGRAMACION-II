#include <iostream>

using namespace std;

int main()
{

    ///PUNTEROS
    int entero = 8;

    cout << "Que guarda: " << entero << endl;
    cout << "Direcc. memoria: " << &entero << endl;


    int *puntero = &entero;

    cout << "Puntero: " << puntero << endl;
    cout << "Direcc. de puntero: " << &puntero << endl;

    /// Asigno nueva direcc. de memoria

    //puntero = &entero;

    /// Muestro el contenido hacia donde apunta el puntero

    cout << *puntero << endl;

    cout << "----------------------------" << endl;
    ///********* DECLARO VECTORES ******** ///

    int v[3];
    puntero =v;
    cout << "Vec: " << v << endl;

    cout << "Puntero: "<< puntero << endl;
    ///v=&entero; /// PUNTERO A CONSTANTE

    const int e = 5;
    const int *p = &e;
    //*p=&entero;




    return 0;
}
