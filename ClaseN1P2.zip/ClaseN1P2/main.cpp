#include <iostream>


using namespace std;

/**
void funcion1(int n){

    cout << "Soy funcion: " << endl;
    cout << "N: "<< &n<< endl;
    cout << "N: "<< n<< endl;
}
int funcion2(int n){

    cout << "Soy funcion: " << endl;
    cout << "N: "<< &n<< endl;
    cout << "N: "<< n<< endl;
    return n*2;
}
void funcion3(const int &numero){

    cout << "Soy funcion: " << endl;
    cout << "N: "<< &numero<< endl;
    cout << "N: "<< numero<< endl;
    ///numero*=2;
}


void funcion5 (int *v, int t){
    for (int i = 0; i<t; i++){
        ///v[i]= i+1;
        ///Notacion de punteros
        *(v+i)=i+1;
    }
}
void funcion6 (int v[],int t){
    for (int i=0; i<t; i++){
        cout << v[i]<< "\t";

}
*/
void funcion7 (int *n1, int *n2){
    cout << n1 << endl;
    *n1*=2;
    *n2*=3;
}

int main()
{
    /// 1er clase Programacion II


    //int entero=0;

    /**

    cout << "verdadero" << endl;
    cout << "Entero: " << sizeof (int) << " Bytes" << endl;
    cout << "Entero: " << sizeof (float) << " Bytes" << endl;
    cout << "Entero: " << sizeof (double) << " Bytes" << endl;
    cout << "Entero: " << sizeof (bool) << " Bytes" << endl;


    const int CONSTANTE = 6;
    cout <<  CONSTANTE << endl;



    cout << "Entero: " << entero << endl;
    cout << "Entero: " << &entero << endl;




int num= 11;
cout << "Soy main: "<< endl;
cout << "Direcc. num: "<< &num<< endl;
cout << "Cont. num: "<< num<< endl;

funcion3 (num);
cout << "Num: "<< num<< endl;
*/



/**
    /// PUNTEROS ---- Guardan direcciones de memoria

    int num=6, *puntero;
    cout << "Cont. numero: " << num <<  endl;
    cout << "Direcc. numero: " <<  &num << endl;
    cout << "Cont. puntero: " << puntero << endl;
    cout << "Direcc. numero: " <<  &puntero << endl;

    /// ASIGNO DIRECC. MEMORIA DE NUMERO.
    puntero= &num;

    cout <<"Direcc. num c/ puntero: " << puntero << endl;


    cout << "Cont. donde apunta el puntero: " << *puntero << endl;


    ///En este contexto *puntero=55, se llama operador de indireccion
    *puntero = 55;
    cout << "Cont. numero: " << num <<  endl;
*/


    ///VECTORES

    //int v[5] {};

    /*
    for (int i=0; i<5; i++){
        cout << v[i]<< "\n";
    }
    */
    /**
    cout << "Direcc. vector: ";
    cout << v << endl;
    cout << "Direcc. Elementos: "<< endl;
    for (int i=0; i<5; i++){
        cout << "Pos: #" << i+1<< " " << &v[i]<< "\n";
    }
    */

    //funcion5 (v,5);
    //*(v+0)=88;
    ///desplazamiento del vector
    //*(v+4)=88;
    //v[4]=88;

    //funcion6 (v,5);

    ///Trabajo con punteros s/ vectores
    int a=4;
    int b=5;
    funcion7 (&a,&b);
    cout << a << endl;
    cout << b << endl;

    return 0;
}
